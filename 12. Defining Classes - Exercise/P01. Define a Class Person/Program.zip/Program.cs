﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string name = "Peter";
            int age = 20;
            Person person = new Person(name, age);
            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);  
        }
    }
}
